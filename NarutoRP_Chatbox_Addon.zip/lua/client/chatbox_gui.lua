
net.Receive("RP_Chat", function()
    local type = net.ReadString()
    local ply = net.ReadEntity()
    local msg = net.ReadString()

    local colors = {
        me = Color(200, 100, 255),
        it = Color(255, 200, 50),
        na = Color(50, 200, 255)
    }

    local prefix = {
        me = "* " .. ply:Nick() .. " ",
        it = "** ",
        na = "[Annonce] "
    }

    chat.AddText(colors[type], prefix[type] .. msg)

    -- 3D text
    ply.RP3DText = {
        text = msg,
        type = type,
        time = CurTime() + 6
    }
end)

-- Chatbox UI custom
hook.Add("StartChat", "CustomChatBox", function()
    if IsValid(CustomChatBox) then return end

    CustomChatBox = vgui.Create("DFrame")
    CustomChatBox:SetSize(600, 200)
    CustomChatBox:Center()
    CustomChatBox:SetTitle("Chat Naruto RP")
    CustomChatBox:SetVisible(true)
    CustomChatBox:SetDraggable(false)
    CustomChatBox:ShowCloseButton(false)
    CustomChatBox:MakePopup()

    local TextEntry = vgui.Create("DTextEntry", CustomChatBox)
    TextEntry:Dock(BOTTOM)
    TextEntry:RequestFocus()
    TextEntry.OnEnter = function(self)
        LocalPlayer():ConCommand("say " .. self:GetValue())
        self:SetText("")
        CustomChatBox:SetVisible(false)
    end

    return true
end)

hook.Add("FinishChat", "CloseCustomChatBox", function()
    if IsValid(CustomChatBox) then
        CustomChatBox:SetVisible(false)
    end
end)
