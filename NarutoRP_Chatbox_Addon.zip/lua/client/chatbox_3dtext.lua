
hook.Add("PostPlayerDraw", "RP_3DText_Display", function(ply)
    if not ply.RP3DText then return end
    if CurTime() > ply.RP3DText.time then
        ply.RP3DText = nil
        return
    end

    local ang = LocalPlayer():EyeAngles()
    local pos = ply:GetPos() + Vector(0, 0, 85)

    ang:RotateAroundAxis(ang:Right(), 90)
    ang:RotateAroundAxis(ang:Up(), -90)

    cam.Start3D2D(pos, Angle(0, ang.y, 90), 0.1)
        draw.SimpleTextOutlined(
            ply.RP3DText.text,
            "DermaLarge",
            0, 0,
            ply.RP3DText.type == "me" and Color(200, 100, 255) or Color(255, 200, 50),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
            1, Color(0, 0, 0)
        )
    cam.End3D2D()
end)
