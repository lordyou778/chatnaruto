
if SERVER then
    AddCSLuaFile("client/chatbox_gui.lua")
    AddCSLuaFile("client/chatbox_3dtext.lua")
    include("server/chatbox_sv.lua")
else
    include("client/chatbox_gui.lua")
    include("client/chatbox_3dtext.lua")
end
