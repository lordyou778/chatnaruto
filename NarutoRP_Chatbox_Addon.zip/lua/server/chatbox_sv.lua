
util.AddNetworkString("RP_Chat")

local function SendRPMessage(type, ply, msg)
    if type == "na" then
        net.Start("RP_Chat")
        net.WriteString(type)
        net.WriteEntity(ply)
        net.WriteString(msg)
        net.Broadcast()
    else
        for _, v in ipairs(player.GetAll()) do
            if v:GetPos():DistToSqr(ply:GetPos()) <= 500*500 then
                net.Start("RP_Chat")
                net.WriteString(type)
                net.WriteEntity(ply)
                net.WriteString(msg)
                net.Send(v)
            end
        end
    end
end

hook.Add("PlayerSay", "RP_Chat_Handler", function(ply, text)
    local lower = string.lower(text)
    if string.sub(lower, 1, 4) == "/me " then
        SendRPMessage("me", ply, string.sub(text, 5))
        return ""
    elseif string.sub(lower, 1, 4) == "/it " then
        SendRPMessage("it", ply, string.sub(text, 5))
        return ""
    elseif string.sub(lower, 1, 4) == "/na " then
        SendRPMessage("na", ply, string.sub(text, 5))
        return ""
    end
end)
